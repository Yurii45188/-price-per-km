package ua.kmcalculator;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class FloatingCalculatorService extends Service {
    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private View panel;
    private EditText fare, distance;
    private TextView commission, net, perKm;
    private boolean minimized = false;
    private final DecimalFormat fmt = new DecimalFormat("0.00",
        DecimalFormatSymbols.getInstance(Locale.US));

    @Override public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        showPanel();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(1, 0xFF374151);
        return d;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private void showPanel() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(16, 12, 16, 16);
        card.setBackground(bg(0xFF111827, 22));
        panel = card;

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("₴ / KM", 18, Color.WHITE);
        brand.setTypeface(null, Typeface.BOLD);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView minimize = text("—", 25, 0xFFCBD5E1);
        minimize.setPadding(12, 0, 12, 0);
        minimize.setOnClickListener(v -> minimizePanel());
        header.addView(minimize);
        TextView close = text("×", 27, 0xFFFCA5A5);
        close.setPadding(8, 0, 4, 0);
        close.setOnClickListener(v -> stopSelf());
        header.addView(close);
        card.addView(header);
        header.setOnTouchListener(new DragTouchListener());

        fare = field("Сума поїздки, грн");
        distance = field("Кілометраж, км");
        card.addView(label("Вартість поїздки"));
        card.addView(fare);
        card.addView(label("Кілометраж"));
        card.addView(distance);

        commission = resultRow("Комісія 23%", "0,00 грн");
        net = resultRow("Чистий дохід", "0,00 грн");

        TextView resultLabel = text("ЧИСТА ВАРТІСТЬ 1 КМ", 11, 0xFF9CA3AF);
        resultLabel.setPadding(0, 12, 0, 2);
        card.addView(resultLabel);
        perKm = text("— грн/км", 27, 0xFF86EFAC);
        perKm.setTypeface(null, Typeface.BOLD);
        card.addView(perKm);

        TextView note = text("Комісія фіксована: 23%", 10, 0xFF9CA3AF);
        note.setPadding(0, 8, 0, 0);
        card.addView(note);

        TextWatcher watcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int count, int after) {}
            public void onTextChanged(CharSequence s, int st, int before, int count) { calculate(); }
            public void afterTextChanged(Editable e) {}
        };
        fare.addTextChangedListener(watcher);
        distance.addTextChangedListener(watcher);
        panel = card;

        params = new WindowManager.LayoutParams(
            dp(300), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = dp(12);
        params.y = dp(100);
        wm.addView(panel, params);
    }

    private TextView label(String s) {
        TextView t = text(s, 12, 0xFFD1D5DB);
        t.setPadding(0, 9, 0, 4);
        return t;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xFF9CA3AF);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setPadding(dp(10), 0, dp(10), 0);
        e.setBackground(bg(0xFF1F2937, 12));
        e.setSelectAllOnFocus(false);
        e.setHeight(dp(46));
        return e;
    }

    private TextView resultRow(String name, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView left = text(name, 13, 0xFFD1D5DB);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
        TextView right = text(value, 14, Color.WHITE);
        right.setTypeface(null, Typeface.BOLD);
        row.addView(right);
        ((LinearLayout) panelOrNull()).addView(row);
        return right;
    }

    private View panelOrNull() { return panel == null ? new LinearLayout(this) : panel; }

    private void calculate() {
        double amount = number(fare == null ? "" : fare.getText().toString());
        double km = number(distance == null ? "" : distance.getText().toString());
        double fee = amount * 0.23;
        double clean = amount - fee;
        commission.setText(fmt.format(fee) + " грн");
        net.setText(fmt.format(clean) + " грн");
        perKm.setText(km > 0 && amount > 0 ? fmt.format(clean / km) + " грн/км" : "— грн/км");
    }

    private double number(String s) {
        try { return Double.parseDouble(s.replace(',', '.').trim()); }
        catch (Exception e) { return 0; }
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void minimizePanel() {
        if (minimized) return;
        wm.removeView(panel);
        TextView bubble = text("₴", 22, Color.WHITE);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(bg(0xFF166534, 100));
        bubble.setOnClickListener(v -> {
            wm.removeView(bubble);
            minimized = false;
            showPanel();
        });
        params = new WindowManager.LayoutParams(dp(54), dp(54),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = dp(12); params.y = dp(140);
        wm.addView(bubble, params);
        minimized = true;
    }

    private class DragTouchListener implements View.OnTouchListener {
        int startX, startY; float touchX, touchY;
        public boolean onTouch(View v, MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                startX = params.x; startY = params.y;
                touchX = e.getRawX(); touchY = e.getRawY(); return true;
            } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                params.x = startX - (int)(e.getRawX() - touchX);
                params.y = startY + (int)(e.getRawY() - touchY);
                wm.updateViewLayout(panel, params); return true;
            }
            return true;
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        if (panel != null && panel.isAttachedToWindow()) wm.removeView(panel);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
