package ua.kmcalculator;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 1001;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 64, 48, 48);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF101827);

        TextView title = new TextView(this);
        title.setText("₴ / KM");
        title.setTextSize(32);
        title.setTextColor(0xFFFFFFFF);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView desc = new TextView(this);
        desc.setText("Плаваючий калькулятор чистої вартості кілометра. Комісія — 23%.");
        desc.setTextSize(16);
        desc.setTextColor(0xFFD1D5DB);
        desc.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.setMargins(0, 24, 0, 32);
        root.addView(desc, dp);

        Button start = new Button(this);
        start.setText("УВІМКНУТИ КАЛЬКУЛЯТОР");
        start.setOnClickListener(v -> enableAndStart());
        root.addView(start, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = new TextView(this);
        hint.setText("Після надання дозволу повернись сюди й натисни кнопку. Віконце можна перетягувати за верхню панель.");
        hint.setTextColor(0xFF9CA3AF);
        hint.setTextSize(14);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, 28, 0, 0);
        root.addView(hint, hp);
        setContentView(root);
    }

    private void enableAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQUEST_OVERLAY);
            return;
        }
        startService(new Intent(this, FloatingCalculatorService.class));
        finish();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, FloatingCalculatorService.class));
            finish();
        }
    }
}
